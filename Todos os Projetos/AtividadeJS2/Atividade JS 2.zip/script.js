const NomeBanda = document.querySelector('h2');

NomeBanda.textContent = 'Charlie Brown Jr.';
